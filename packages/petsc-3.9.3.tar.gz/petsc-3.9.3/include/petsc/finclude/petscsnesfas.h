!
!  Include file for Fortran use of the FAS nonlinear solvers in PETSc
!
#if !defined (__PETSCSNESFASDEF_H)
#define __PETSCSNESFASDEF_H

#include "petsc/finclude/petscsnes.h"

#define SNESFASType PetscEnum

#endif
